# know-me
Simple description of myself to the person kind enough to know about me.
